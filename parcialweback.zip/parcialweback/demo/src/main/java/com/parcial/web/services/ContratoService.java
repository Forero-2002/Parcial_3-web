package com.parcial.web.services;

import com.parcial.web.entities.Contrato;
import com.parcial.web.entities.Entidad;
import com.parcial.web.repositories.ContratoRepository;
import com.parcial.web.repositories.EntidadRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ContratoService {

    private final ContratoRepository contratoRepository;
    private final EntidadRepository entidadRepository;

    public ContratoService(ContratoRepository contratoRepository, EntidadRepository entidadRepository) {
        this.contratoRepository = contratoRepository;
        this.entidadRepository = entidadRepository;
    }

    public Contrato crearContrato(Contrato contrato, Long entidadId) {
        Optional<Entidad> entidadOpt = entidadRepository.findById(entidadId);
        entidadOpt.ifPresent(contrato::setEntidad);
        return contratoRepository.save(contrato);
    }

    public List<Contrato> obtenerTodos() {
        return contratoRepository.findAll();
    }

    public Optional<Contrato> obtenerPorId(Long id) {
        return contratoRepository.findById(id);
    }

    public Contrato actualizarContrato(Contrato contrato, Long entidadId) {
        Optional<Entidad> entidadOpt = entidadRepository.findById(entidadId);
        entidadOpt.ifPresent(contrato::setEntidad);
        return contratoRepository.save(contrato);
    }

    public void eliminarContrato(Long id) {
        contratoRepository.deleteById(id);
    }
}
