package com.parcial.web.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EntidadDTO {
    private Long id;
    private String nit;
    private String nombre;
    private List<ContratoDTO> contratos; // Puedes omitirlo si no quieres enviar contratos en la entidad
}
