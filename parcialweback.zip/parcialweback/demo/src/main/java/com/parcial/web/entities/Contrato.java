package com.parcial.web.entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "contrato")
public class Contrato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 255, nullable = false)
    private String identificador;

    private Double valor;

    @Column(name = "nombre_contratante", length = 255)
    private String nombreContratante;

    @Column(name = "documento_contratante", length = 255)
    private String documentoContratante;

    @Column(name = "nombre_contratatista", length = 255)
    private String nombreContratatista;

    @Column(name = "documento_contratatista", length = 255)
    private String documentoContratatista;

    @Column(name = "fecha_inicial")
    private LocalDate fechaInicial;

    @Column(name = "fecha_final")
    private LocalDate fechaFinal;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "entidad_id")
    private Entidad entidad;

    // Constructor vacío
    public Contrato() {
    }

    // Constructor con parámetros
    public Contrato(Long id, String identificador, Double valor,
            String nombreContratante, String documentoContratante,
            String nombreContratatista, String documentoContratatista,
            LocalDate fechaInicial, LocalDate fechaFinal, Entidad entidad) {
        this.id = id;
        this.identificador = identificador;
        this.valor = valor;
        this.nombreContratante = nombreContratante;
        this.documentoContratante = documentoContratante;
        this.nombreContratatista = nombreContratatista;
        this.documentoContratatista = documentoContratatista;
        this.fechaInicial = fechaInicial;
        this.fechaFinal = fechaFinal;
        this.entidad = entidad;
    }

    // Getters y setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getNombreContratante() {
        return nombreContratante;
    }

    public void setNombreContratante(String nombreContratante) {
        this.nombreContratante = nombreContratante;
    }

    public String getDocumentoContratante() {
        return documentoContratante;
    }

    public void setDocumentoContratante(String documentoContratante) {
        this.documentoContratante = documentoContratante;
    }

    public String getNombreContratatista() {
        return nombreContratatista;
    }

    public void setNombreContratatista(String nombreContratatista) {
        this.nombreContratatista = nombreContratatista;
    }

    public String getDocumentoContratatista() {
        return documentoContratatista;
    }

    public void setDocumentoContratatista(String documentoContratatista) {
        this.documentoContratatista = documentoContratatista;
    }

    public LocalDate getFechaInicial() {
        return fechaInicial;
    }

    public void setFechaInicial(LocalDate fechaInicial) {
        this.fechaInicial = fechaInicial;
    }

    public LocalDate getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(LocalDate fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public Entidad getEntidad() {
        return entidad;
    }

    public void setEntidad(Entidad entidad) {
        this.entidad = entidad;
    }
}
