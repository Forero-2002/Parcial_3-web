package com.parcial.web.controllers;

import com.parcial.web.entities.Contrato;
import com.parcial.web.services.ContratoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/contratos")
public class ContratoController {

    private final ContratoService contratoService;

    public ContratoController(ContratoService contratoService) {
        this.contratoService = contratoService;
    }

    @PostMapping("/{entidadId}")
    public ResponseEntity<Contrato> crearContrato(@RequestBody Contrato contrato,
            @PathVariable Long entidadId) {
        Contrato nuevoContrato = contratoService.crearContrato(contrato, entidadId);
        return ResponseEntity.ok(nuevoContrato);
    }

    @GetMapping
    public ResponseEntity<List<Contrato>> listarContratos() {
        return ResponseEntity.ok(contratoService.obtenerTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Contrato> obtenerContrato(@PathVariable Long id) {
        return contratoService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/{entidadId}")
    public ResponseEntity<Contrato> actualizarContrato(@PathVariable Long id,
            @PathVariable Long entidadId,
            @RequestBody Contrato contrato) {
        contrato.setId(id);
        Contrato actualizado = contratoService.actualizarContrato(contrato, entidadId);
        return ResponseEntity.ok(actualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarContrato(@PathVariable Long id) {
        contratoService.eliminarContrato(id);
        return ResponseEntity.noContent().build();
    }
}
