package com.parcial.web.services;

import com.parcial.web.entities.Entidad;
import com.parcial.web.repositories.EntidadRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EntidadService {

    private final EntidadRepository entidadRepository;

    public EntidadService(EntidadRepository entidadRepository) {
        this.entidadRepository = entidadRepository;
    }

    public Entidad crearEntidad(Entidad entidad) {
        return entidadRepository.save(entidad);
    }

    public List<Entidad> obtenerTodas() {
        return entidadRepository.findAll();
    }

    public Optional<Entidad> obtenerPorId(Long id) {
        return entidadRepository.findById(id);
    }

    public Entidad actualizarEntidad(Entidad entidad) {
        return entidadRepository.save(entidad);
    }

    public void eliminarEntidad(Long id) {
        entidadRepository.deleteById(id);
    }
}
