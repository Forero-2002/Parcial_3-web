package com.parcial.web.controllers;

import com.parcial.web.entities.Entidad;
import com.parcial.web.services.EntidadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/entidades")
public class EntidadController {

    private final EntidadService entidadService;

    public EntidadController(EntidadService entidadService) {
        this.entidadService = entidadService;
    }

    @PostMapping
    public ResponseEntity<Entidad> crearEntidad(@RequestBody Entidad entidad) {
        Entidad nuevaEntidad = entidadService.crearEntidad(entidad);
        return ResponseEntity.ok(nuevaEntidad);
    }

    @GetMapping
    public ResponseEntity<List<Entidad>> listarEntidades() {
        return ResponseEntity.ok(entidadService.obtenerTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Entidad> obtenerEntidad(@PathVariable Long id) {
        return entidadService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Entidad> actualizarEntidad(@PathVariable Long id, @RequestBody Entidad entidad) {
        entidad.setId(id);
        Entidad actualizada = entidadService.actualizarEntidad(entidad);
        return ResponseEntity.ok(actualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEntidad(@PathVariable Long id) {
        entidadService.eliminarEntidad(id);
        return ResponseEntity.noContent().build();
    }
}
