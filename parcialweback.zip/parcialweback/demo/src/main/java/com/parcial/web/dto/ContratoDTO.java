package com.parcial.web.dto;

import lombok.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContratoDTO {
    private Long id;
    private String identificador;
    private Double valor;
    private String nombreContratante;
    private String documentoContratante;
    private String nombreContratatista;
    private String documentoContratatista;
    private LocalDate fechaInicial;
    private LocalDate fechaFinal;
    private Long entidadId; // Para referenciar la entidad asociada
}
